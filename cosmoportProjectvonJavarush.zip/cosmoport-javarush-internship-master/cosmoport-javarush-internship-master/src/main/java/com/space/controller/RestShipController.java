
--module-path ${PATH_TO_FX} --add-modules javafx.controls,javafx.fxml, javafx.graphics,javafx.web;



--module-path "C:\opt\javafx-sdk-15.0.1\lib" --add-modules javafx.controls,javafx.fxml,javafx.graphics



--module-path "C:\opt\javafx-sdk-15.0.1\lib" --add-modules javafx.controls,javafx.fxml


javac--module-path "C:\opt\javafx-sdk-15.0.1\lib" --add-modules javafx.controls,javafx.fxml
javac--module-path %PATH_TO_FX% --add-modules javafx.controls,javafx.fxml


%JAVA_HOME% \ bin



javac --module-path %PATH_TO_FX% --add-modules javafx.controls,javafx.fxml HelloFX.java




--module-path %PATH_TO_FX% --add-modules javafx.controls